package com.example.project.repository;

import com.example.project.model.Bid;
import com.example.project.model.Product;
import com.example.project.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface BidRepository extends JpaRepository<Bid, Long> {
    List<Bid> findByProduct_Id(Long productId);
    Optional<Bid> findBidById(Long bidId);
    List<Bid> findByBidder(User bidder);
    List<Bid> findByProductAndExpirationTimeAfter(Product product, LocalDateTime expirationTime);
    Optional<Bid> findTopByProductAndExpirationTimeAfterOrderByBidAmountDesc(Product product, LocalDateTime expirationTime);
}


