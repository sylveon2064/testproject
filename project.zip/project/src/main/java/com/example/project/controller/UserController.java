package com.example.project.controller;

import com.example.project.model.User;
import com.example.project.service.UserMaskingService;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserMaskingService userMaskingService;

    @GetMapping("/profile")
    public String userProfile(Model model) {
        // Get the authenticated user's details
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userEmail = authentication.getName();

        // Check if the user is already registered
        User existingUser = userService.findByEmail(userEmail);
        if (existingUser == null) {
            // If not registered, register the user with a random name
            String randomName = userMaskingService.generateUniqueName();
            User newUser = new User();
            newUser.setEmail(userEmail);
            newUser.setUsername(randomName);
            userService.registerUser(newUser);
        }

        // Fetch the user details again after registration
        User user = userService.findByEmail(userEmail);

        // Add user details to the model
        model.addAttribute("user", user);

        // Render the user profile page
        return "profile";
    }
}
