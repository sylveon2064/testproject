package com.example.project.service;

import com.example.project.model.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;

public class CustomUserDetails implements UserDetails {

    private final User user;

    public CustomUserDetails(User user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // You can customize this method based on your user roles/authorities
        return Collections.singleton(new SimpleGrantedAuthority("ROLE_USER"));
    }

    @Override
    public String getPassword() {
        return null;
    }

    /*@Override
    public String getPassword() {
        return user.getPassword();
    }*/

    @Override
    public String getUsername() {
        return user.getUsername();
    }

    // Additional methods from UserDetails interface...

    @Override
    public boolean isAccountNonExpired() {
        return true; // Modify as needed
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Modify as needed
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Modify as needed
    }

    @Override
    public boolean isEnabled() {
        return false;
    }

    /*@Override
    public boolean isEnabled() {
        return user.isActive(); // You might want to use an 'active' flag in your User entity
    }*/
}

