package com.example.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    @Autowired
    public ChatService chatService;

    // Get chat messages between two users
    @GetMapping("/messages")
    public ResponseEntity<List<ChatMessage>> getChatMessages(
            @RequestParam("senderId") Long senderId,
            @RequestParam("receiverId") Long receiverId
    ) {
        List<ChatMessage> messages = chatService.getChatMessages(senderId, receiverId);
        return ResponseEntity.ok(messages);
    }

    // Send a new chat message
    @PostMapping("/send-message")
    public ResponseEntity<ChatMessage> sendMessage(@RequestBody ChatMessage newMessage) {
        ChatMessage sentMessage = chatService.sendMessage(newMessage);
        return ResponseEntity.ok(sentMessage);
    }

    // Update chat message details
    @PutMapping("/update-message/{messageId}")
    public ResponseEntity<ChatMessage> updateMessage(@PathVariable Long messageId, @RequestBody ChatMessage updatedMessage) {
        ChatMessage message = chatService.updateMessage(messageId, updatedMessage);
        if (message != null) {
            return ResponseEntity.ok(message);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete chat message by ID
    @DeleteMapping("/delete-message/{messageId}")
    public ResponseEntity<Void> deleteMessage(@PathVariable Long messageId) {
        boolean deleted = chatService.deleteMessage(messageId);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

