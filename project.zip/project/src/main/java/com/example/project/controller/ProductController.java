package com.example.project.controller;

import com.example.project.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/create")
    public ResponseEntity<Product> createProduct(
            @RequestParam("name") String name,
            @RequestParam("description") String description
    ) {
        Product newProduct = new Product();
        newProduct.setName(name);
        newProduct.setDescription(description);


        Product createdProduct = productService.createProduct(newProduct);
        return ResponseEntity.ok(createdProduct);
    }
}
