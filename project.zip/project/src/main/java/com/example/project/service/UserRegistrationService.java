package com.example.project.service;
import com.example.project.exception.EmailAlreadyExistsException;
import com.example.project.model.User;
import com.example.project.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserRegistrationService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserMaskingService userMaskingService;

    public User registerUser(UserRegistrationRequest registrationRequest) {
        // Check if the email is already registered
        if (userRepository.findByEmail(registrationRequest.getEmail()).isPresent()) {
            throw new EmailAlreadyExistsException("Email is already registered");
        }

        // Create a new user with a unique fake name
        User newUser = new User();
        newUser.setUsername(userMaskingService.generateUniqueName());
        newUser.setEmail(registrationRequest.getEmail());
        // Set other user properties...

        // Save the user to the database
        return userRepository.save(newUser);
    }
}

