package com.example.project.service;

import com.example.project.exception.EmailAlreadyExistsException;
import com.example.project.model.User;
import com.example.project.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private static UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserMaskingService userMaskingService;

    public void registerUser(User user) {
        // Check if the email is already registered
        if (emailExists(user.getEmail())) {
            throw new EmailAlreadyExistsException("Email is already registered");
        }

        // Set a random username using the UserMaskingService
        user.setUsername(userMaskingService.generateUniqueName());

        // Encrypt the password before saving
        //user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Save the user to the database
        userRepository.save(user);
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }

    private boolean emailExists(String email) {
        return userRepository.findByEmail(email).isPresent();
    }

    public User findById(Long userId) {
        // Use the UserRepository to find a user by ID
        return userRepository.findById(userId).orElse(null);
    }
}

