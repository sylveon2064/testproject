package com.example.project.service;

import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class UserMaskingService {

    private final Set<String> usedNames = new HashSet<>();

    public String generateUniqueName() {
        String name;
        do {
            name = generateRandomName();
        } while (usedNames.contains(name));

        usedNames.add(name);
        return name;
    }

    private String generateRandomName() {
        // Implement your logic to generate a random name
        // This can be as simple as combining a prefix with a random number
        return "User" + (int) (Math.random() * 1000);
    }
}

