package com.example.project.controller;

import com.example.project.model.Bid;
import com.example.project.model.User;
import com.example.project.service.BidService;
import com.example.project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/bids")
public class BidController {

    @Autowired
    private BidService bidService;

    @Autowired
    private UserService userService;

    // Get all bids for a specific product
    @GetMapping("/product/{productId}")
    public ResponseEntity<List<Bid>> getBidsForProduct(@PathVariable Long productId) {
        List<Bid> bids = bidService.getBidsForProduct(productId);
        return ResponseEntity.ok(bids);
    }

    // Get bid by ID
    @GetMapping("/{bidId}")
    public ResponseEntity<Bid> getBidById(@PathVariable Long bidId) {
        Bid bid = bidService.getBidById(bidId);
        if (bid != null) {
            return ResponseEntity.ok(bid);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Place a new bid on a product
    @PostMapping("/place-bid")
    public ResponseEntity<Bid> placeBid(
            @RequestParam("productId") Long productId,
            @RequestParam("amount") BigDecimal amount,
            @RequestParam("userId") Long userId
            ){
        User bidder = userService.findById(userId);
        Bid newBid = bidService.placeBid(productId, bidder, amount);
        return ResponseEntity.ok(newBid);
    }

    // Update bid details
    @PutMapping("/{bidId}")
    public ResponseEntity<Bid> updateBid(@PathVariable Long bidId, @RequestBody Bid updatedBid) {
        // Assuming Bid class has a method like getAmount() to retrieve the bid amount
        BigDecimal updatedBidAmount = updatedBid.getAmount();

        Bid bid = bidService.updateBid(bidId, updatedBidAmount);
        if (bid != null) {
            return ResponseEntity.ok(bid);
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    // Delete bid by ID
    @DeleteMapping("/{bidId}")
    public ResponseEntity<Void> deleteBid(@PathVariable Long bidId) {
        boolean deleted = bidService.deleteBid(bidId);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

