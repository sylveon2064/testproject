package com.example.project.service;

import com.example.project.exception.BidNotFoundException;
import com.example.project.model.Bid;
import com.example.project.model.Product;
import com.example.project.model.User;
import com.example.project.repository.BidRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BidService {

    @Autowired
    private BidRepository bidRepository;

    @Autowired
    private ProductService productService;

    // Place a bid on a product with a 24-hour expiration time
    public Bid placeBid(Long productId, User bidder, BigDecimal bidAmount) {
        Product product = productService.getProductById(productId);

        // Set bid expiration time to 24 hours from now
        LocalDateTime expirationTime = LocalDateTime.now().plusHours(24);

        Bid newBid = new Bid(product, bidder, bidAmount, LocalDateTime.now(), expirationTime);

        product.addBid(newBid);
        return bidRepository.save(newBid);
    }
    public Bid getBidById(Long bidId) {
        return bidRepository.findBidById(bidId)
                .orElseThrow(() -> new RuntimeException("Bid not found with id: " + bidId));
    }


    // Get all unexpired bids for a specific product
    public List<Bid> getUnexpiredBidsForProduct(Long productId) {
        Product product = productService.getProductById(productId);
        return bidRepository.findByProductAndExpirationTimeAfter(product, LocalDateTime.now());
    }

    // Get the highest unexpired bid for a specific product
    public Bid getHighestUnexpiredBidForProduct(Long productId) {
        Product product = productService.getProductById(productId);
        return bidRepository.findTopByProductAndExpirationTimeAfterOrderByBidAmountDesc(product, LocalDateTime.now())
                .orElse(null);
    }

    // Get all bids placed by a specific user
    public List<Bid> getBidsByUser(User bidder) {
        return bidRepository.findByBidder(bidder);
    }
    public List<Bid> getBidsForProduct(Long productId) {
        return bidRepository.findByProduct_Id(productId);
    }
    public boolean deleteBid(Long bidId) {
        // Delete a bid by its ID from the repository
        bidRepository.deleteById(bidId);
        return true;
    }
    public Bid updateBid(Long bidId, BigDecimal newAmount) {
        // Update a bid's amount by its ID
        Bid existingBid = bidRepository.findById(bidId)
                .orElseThrow(() -> new BidNotFoundException(bidId));

        // Update bid details
        existingBid.setAmount(newAmount);
        // You can update other bid details here if needed

        // Save the updated bid to the repository
        return bidRepository.save(existingBid);
    }
}
